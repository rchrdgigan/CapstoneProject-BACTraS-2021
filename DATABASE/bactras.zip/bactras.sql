-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2021 at 02:59 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bactras`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(11) NOT NULL,
  `firstName` varchar(60) NOT NULL,
  `middleName` varchar(60) NOT NULL,
  `lastName` varchar(60) NOT NULL,
  `emailAddress` varchar(60) NOT NULL,
  `contactNumber` varchar(30) NOT NULL,
  `adminUsername` varchar(60) NOT NULL,
  `adminPass` varchar(150) NOT NULL,
  `role` varchar(30) NOT NULL,
  `createAt` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `firstName`, `middleName`, `lastName`, `emailAddress`, `contactNumber`, `adminUsername`, `adminPass`, `role`, `createAt`) VALUES
(1, 'adminFirstname12312312', 'adminMiddlename', 'adminLastname', 'admin@gmail.com', '12345678910', 'admin', 'admin1234', 'Admin', '2021-04-06 00:19:29am'),
(5, 'superadmin', 'superadmin', 'superadmin', 'superadmin@admin.com', '12345678901', 'superadmin', '$2y$10$zy9TWT7hhR14vniwmXJ16.gcvu4j/PxFjn8opwBrXnVDjv4dahlB6', 'Super-admin', '2021-05-27 20:23:08pm');

-- --------------------------------------------------------

--
-- Table structure for table `tb_brgy`
--

CREATE TABLE `tb_brgy` (
  `id` int(11) NOT NULL,
  `location` varchar(60) NOT NULL,
  `brgyUsername` varchar(60) NOT NULL,
  `brgyPass` varchar(60) NOT NULL,
  `role` varchar(30) NOT NULL,
  `createAt` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_brgy`
--

INSERT INTO `tb_brgy` (`id`, `location`, `brgyUsername`, `brgyPass`, `role`, `createAt`) VALUES
(1, 'Obrero Bulan Sorsogon', 'barangayofbulan', 'bulansorsogon4706', 'Brgy', '2021-04-1 11:56:33am');

-- --------------------------------------------------------

--
-- Table structure for table `tb_citizen`
--

CREATE TABLE `tb_citizen` (
  `id` int(11) NOT NULL,
  `firstName` varchar(60) NOT NULL,
  `middleName` varchar(60) NOT NULL,
  `lastName` varchar(60) NOT NULL,
  `suffix` varchar(60) NOT NULL,
  `birthDate` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `contactNumber` varchar(30) NOT NULL,
  `homeAddress` varchar(60) NOT NULL,
  `citizenUsername` varchar(30) NOT NULL,
  `citizenPass` varchar(150) NOT NULL,
  `role` varchar(30) NOT NULL,
  `createAt` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_citizen`
--

INSERT INTO `tb_citizen` (`id`, `firstName`, `middleName`, `lastName`, `suffix`, `birthDate`, `gender`, `contactNumber`, `homeAddress`, `citizenUsername`, `citizenPass`, `role`, `createAt`, `status`) VALUES
(49, 'Richard', 'Pardo', 'Gigantone', '', '1995-02-10', 'Male', '09519854673', 'Obrero Bulan Sorsogon', 'richard.gigantone', '$2y$10$QkDWg7ZAaRCdugrk0CNhJO802/SwN4C8dfaUSizCspERPOjD9VICu', 'Person', '2021-07-06 23:14:32pm', 'active'),
(50, 'Chard', 'Pards', 'Giga', '', '1995-12-10', 'Male', '09519854673', 'Obrero Bulan Sorsogon', 'chad.gigan', '$2y$10$bEt/nG.nP1SvzEMxX.4YVeJPUUN/gmxiAEDCHFkkthlCjwgDkktS2', 'Person', '2021-07-06 23:15:39pm', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `tb_establishment`
--

CREATE TABLE `tb_establishment` (
  `id` int(11) NOT NULL,
  `businessName` varchar(60) NOT NULL,
  `businessAddress` varchar(60) NOT NULL,
  `contactPerson` varchar(30) NOT NULL,
  `emailAddress` varchar(60) NOT NULL,
  `contactNumber` varchar(30) NOT NULL,
  `estabUsername` varchar(30) NOT NULL,
  `estabPass` varchar(150) NOT NULL,
  `role` varchar(30) NOT NULL,
  `createAt` varchar(30) NOT NULL,
  `status` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_establishment`
--

INSERT INTO `tb_establishment` (`id`, `businessName`, `businessAddress`, `contactPerson`, `emailAddress`, `contactNumber`, `estabUsername`, `estabPass`, `role`, `createAt`, `status`) VALUES
(26, 'Jolibee', 'Zone 4 (Central Business District) Bulan Sorsogon', 'Jolibee', 'jolibee@gmail.com', '21223412312', 'jolibee', 'q1w2e3r4t5y6', 'Merchant', '2021-06-16 15:07:57pm', 'active'),
(27, 'LCC Super Market', 'Zone 4 (Central Business District) Bulan Sorsogon', 'Lcc Super Visor', 'lccbulan@gmail.com', '09519854673', 'lccbulan', 'q1w2e3r4t5y6', 'Merchant', '2021-07-06 23:05:52pm', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `tb_tracinglog`
--

CREATE TABLE `tb_tracinglog` (
  `tracing_id` int(11) NOT NULL,
  `citizen_id` int(11) NOT NULL,
  `estab_id` int(11) NOT NULL,
  `tracingDateTime` datetime NOT NULL,
  `temperature` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_brgy`
--
ALTER TABLE `tb_brgy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_citizen`
--
ALTER TABLE `tb_citizen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_establishment`
--
ALTER TABLE `tb_establishment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_tracinglog`
--
ALTER TABLE `tb_tracinglog`
  ADD PRIMARY KEY (`tracing_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_brgy`
--
ALTER TABLE `tb_brgy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_citizen`
--
ALTER TABLE `tb_citizen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `tb_establishment`
--
ALTER TABLE `tb_establishment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tb_tracinglog`
--
ALTER TABLE `tb_tracinglog`
  MODIFY `tracing_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
